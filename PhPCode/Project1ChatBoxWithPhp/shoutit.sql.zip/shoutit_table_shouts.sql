
-- --------------------------------------------------------

--
-- Table structure for table `shouts`
--

CREATE TABLE `shouts` (
  `id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shouts`
--

INSERT INTO `shouts` (`id`, `user`, `message`, `time`) VALUES
(1, 'maedeh', 'salam khubin?', '12:52:23'),
(2, 'razie', 'salam mamnoon to khubi?che khabar?', '13:23:00'),
(3, 'elham', 'manam khubam', '14:00:00'),
(4, 'maedeh', 'salamati khabari nist', '19:00:00'),
(5, 'elham', 'emruz miyayd berim birun?', '20:25:50'),
(19, 'maedeh', 'motaesafam emrooz nemitoonam', '03:18:13'),
(20, 'elham', 'ok!', '03:18:31');
